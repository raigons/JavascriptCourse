describe("Cart", function() {
  describe("new cart", function() {
    var cart;

    beforeEach(function() {
      cart = new Cart();
    });

    it("returns zero as total", function() {
      expect(cart.total()).toEqual(0);
    });

    it("has no items", function() {
      expect(cart.getItems()).toEqual([]);
    });
  });

  describe("existing cart", function() {

  });
});